// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB8_b28HHXvE41_7EqVQ1FDWoB8cqOYcQo",
  authDomain: "otpa-e58fc.firebaseapp.com",
  projectId: "otpa-e58fc",
  storageBucket: "otpa-e58fc.appspot.com",
  messagingSenderId: "991849729056",
  appId: "1:991849729056:web:455963a1aebaf370c4c045",
  measurementId: "G-BX87QWNHZ1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
