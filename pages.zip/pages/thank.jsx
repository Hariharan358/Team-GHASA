// src/ThanksForVoting.js
import React from 'react';

const ThanksForVoting = () => {
  return (
    <div>
      <h1>Thank You for Voting!</h1>
      <p>Your vote has been recorded. We appreciate your participation!</p>
    </div>
  );
};

export default ThanksForVoting;
