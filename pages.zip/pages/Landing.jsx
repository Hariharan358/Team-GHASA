import React from 'react'
import "../styles/Landing.css";
import { Link } from 'react-router-dom';

const Landing = () => {
  return (
    <div className='landing-main'>
    <h1 className='first'> <span className='sec'>Indian</span> Voting <span className='third'> System!</span></h1>
    <p>Hello and welcome!</p>
    <Link to="/login" className="landing-login-button">Login</Link>
    
  </div>
  )
}

export default Landing