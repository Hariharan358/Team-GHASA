export { default as Dashboard } from "./Dashboard";
export { default as HomeLayout } from "./HomeLayout";
export { default as Landing } from "./Landing";
export { default as Login } from "./Login";
export { default as Register } from "./Register";
export { default as Logout } from "./Logout";
export{ default as CandidateList} from "./CandidateList";
export { default as Candidate} from "./Candidate"; 